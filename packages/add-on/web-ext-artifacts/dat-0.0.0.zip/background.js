browser.webRequest.onBeforeRequest.addListener(function (request) {
  console.log(request)
  return request
}, {urls: ['<all_urls>']}, ['blocking'])

